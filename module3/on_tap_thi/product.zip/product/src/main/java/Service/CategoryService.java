package Service;

import Model.Category;

import java.util.List;

public interface CategoryService {
    List<Category> getListCategory();
}
