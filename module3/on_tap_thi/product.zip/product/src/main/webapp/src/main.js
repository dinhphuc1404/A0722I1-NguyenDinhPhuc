// function onDelete(id) {
//     document.getElementById("id").value = id;
// }
//
// function onEdit(id) {
//     document.getElementById(id+"").value = id;
// }
